# Guns-Dataset
The repository contains labelled images of guns taken from various sources.
<br>

## Description
Images folder has images in <code>jpeg</code> format. Labels folder has <code>txt</code> files where in each file, the first line contains the number of objects in the corresponding image and the next lines contain the co-ordinates of the box describing the object.
<br>
